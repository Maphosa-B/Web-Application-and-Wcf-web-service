﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace StoreProject
{
    
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        int removeProduct(int id);
       
      
        
        [OperationContract]
        int removeUser(int id);
      
       
        [OperationContract]
        int login(string Name, string password);

      
        [OperationContract]
        Invoice getInvoice(int Id);

        [OperationContract]
        List<Invoice> getAllInvoices();

        [OperationContract]
        List<User> getAllUsers();
        
        [OperationContract]
        int addUser(User u);
      
        [OperationContract]
        int editUser(User user);

      
        [OperationContract]
        Product getProduct(int Id);
      
      
        [OperationContract]
        List<Product> getAllProducts();
      
       
        [OperationContract]
        int addProduct(Product p);
       
       
        [OperationContract]
        User getUser(int Id);

      
        [OperationContract]
        bool sellProduct(int productId, int UserId, int pAmount);

        [OperationContract]
        bool addStock(int id, int Amount);


        [OperationContract]
        bool addStockProduct(Stock s);

       
        [OperationContract]
        List<Stock> getAllStocks();

      
        [OperationContract]
        Stock getStock(int id);

       
        [OperationContract]
        List<Invoice> getDailyAllInvoicesByDate(DateTime d );

       
        [OperationContract]
       List<iDate> getAllDates();

       
        [OperationContract]
        bool deleteStock(int id);

       
        [OperationContract]
        bool useStock(int id, int Amount);


    }
}
