﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace StoreProject
{

    public class Service1 : IService1
    {
        // connection to the dbml, which connects to the database
        DataClasses1DataContext db = new DataClasses1DataContext();

        //For Password Encryption 
        SHA1CryptoServiceProvider Sha1 = new SHA1CryptoServiceProvider();
        UTF8Encoding Utf8 = new UTF8Encoding();
       
        //The function is responsible for removing meals  on meals menu
        public int removeProduct(int id)
        {
            var product = getProduct(id);
            if (product != null)
            {
                product.Status = 0;
                try
                {
                    db.SubmitChanges();
                    return 1;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    return -1;
                }
            }
            else
            {
                return 0;
            }
        }

        //Responsible for removing users
        public int removeUser(int id)
        {
            var user = getUser(id);
            if (user != null)
            {
                user.Status = 0;
                try
                {
                    db.SubmitChanges();
                    return 1;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    return -1;
                }
            }
            else
            {
                return 0;
            }
        
        }
     

        //Resonsible for adding meals 
        public int addProduct(Product p)
        {
            var exists = getProduct(p.Id);
            if (exists == null)
            {
                Product tempP = new Product()
                {
                    Date = DateTime.Now,
                    Status = 1,
                    Name = p.Name,
                    Price = p.Price,
                };


                db.Products.InsertOnSubmit(tempP);
                try
                {
                    db.SubmitChanges();
                    //success
                    return 1;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    //error
                    return -1;
                }
            }
            else
            {
                //product exists
                return 0;
            }
        }
       
        //Responsible for returning all invoices for payment history
        public List<Invoice> getAllInvoices()
        {
            var invoice = new List<Invoice>();
            var inv = (from i in db.Invoices
                       orderby i.IssueDate descending
                      select i);
            foreach (Invoice item in inv)
            {
                invoice.Add(item);
            }
            return invoice;
        }

        //Returns all 2nd Role Users, will be used to diplay them when perfoming delete functionality
        public List<User> getAllUsers()
        {
            
            var  data = (from i in db.Users
                         where i.Status ==1 && i.UserType!=1
                         select i);
            if(data!=null)
            {
                var user = new List<User>();
                foreach (User item in data)
                {
                    user.Add(item);
                }
                return user;
            }else
            {
                return null;
            }
            
        }


        //Responsible for adding 2nd role users, will be used to give a 1s role user to add other users
        public int addUser(User u)
        {
            var exists = (from alb in db.Users
                          where alb.FirstName.Equals(u.FirstName.ToUpper()) 
                          select alb).FirstOrDefault();
            if (exists == null)
            {
                User tempUser = new User()
                {
                    Date = DateTime.Now,
                    FirstName = u.FirstName.ToUpper(),
                    Password = u.Password,
                    Status = 1,
                    UserType = 2,
                };

                db.Users.InsertOnSubmit(tempUser);
                try
                {
                    db.SubmitChanges();
                    return 1;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    return -1;
                }
            }
            else
            {
                return 0;
            }
        }
       
        
       //It will be responsible for editing user information
        public int editUser(User user)
        {
            var exists = getUser(user.Id);
            if (exists != null)
            {
                var emailExists = (from us in db.Users
                                   where us.FirstName.Equals(user.FirstName) && us.Id != user.Id && us.Status==1
                                   select us).FirstOrDefault();
                if (emailExists == null)
                {
                    exists.FirstName = user.FirstName.ToUpper();
                    exists.Password = user.Password;
                    try
                    {
                        db.SubmitChanges();
                        return 1;
                    }
                    catch (Exception ex)
                    {
                        ex.GetBaseException();
                        return -1;
                    }
                }
                else
                {
                    return 0;
                }

            }
            else
            {
                return 0;
            }
        }

      
        //Responsible for authitication
        public int login(string Name, string password)
        {
            var data = (from i in db.Users
                        where i.FirstName.Equals(Name.ToUpper()) && i.Status == 1 && password.Equals(i.Password)
                        select i).FirstOrDefault();
            if(data!=null)
            {
                return data.Id;
            }else
            {
                return -1;
            }
        }

        //Will be used locally to check for user existance when perfoming other funtions
        public User getUser(int Id)
        {
            var user = (from u in db.Users
                        where u.Id.Equals(Id) && u.Status ==1
                        select u).FirstOrDefault();

            if (user == null)
            {
                return null;
            }
            else
            {
                return user;
            }
        }

        //Will be used locally to check for meal existance when perfoming other funtions
        public Product getProduct(int Id)
        {
            var product = (from p in db.Products
                           where p.Id.Equals(Id) 
                           select p).FirstOrDefault();

            if (product == null)
            {
                return null;
            }
            else
            {
                return product;
            }
        }

        //Will be used to retrive specic invoice for more information about it
        public Invoice getInvoice(int Id)
        {
            var invoice = (from i in db.Invoices
                           where i.Invoice_Id.Equals(Id)
                           select i).FirstOrDefault();

            if (invoice == null)
            {
                return null;
            }
            else
            {
                return invoice;
            }
        }

        //Resonsible for returning all meals which will be used on retail for trading
        public List<Product> getAllProducts()
        {
            var data = (from i in db.Products
                        select i);
            if(data!=null)
            {
                List<Product> tempProduct = new List<Product>();

                foreach(Product p in  data)
                {
                    tempProduct.Add(p);
                }
                return tempProduct;

            }
            else
            {
                return null;
            }
        }


        //The method adds a transaction to invoice and add date on date table which will be used to sort invoices by dat
        public bool sellProduct(int productId, int UserId, int pAmount)
        {

            var data = (from i in db.Products
                        where i.Status !=0 && i.Id == productId
                        select i).FirstOrDefault();

            var iDateData = (from i in db.iDates
                         where i.Date_ == DateTime.Today
                         select i).FirstOrDefault();

            

            if(data!=null)
            {
                if(iDateData==null)
                {
                    iDate x = new iDate()
                    {
                        Date_ = DateTime.Today.Date
                    };
                    db.iDates.InsertOnSubmit(x);
                }
     
                Invoice tempInvoice = new Invoice()
                {
                    Product_Num = pAmount,
                    Total_Price_Amount = Convert.ToDecimal(data.Price* pAmount),
                    Product_Id = productId,
                    User_ID = UserId,
                    IssueDate = DateTime.Now
                };

                db.Invoices.InsertOnSubmit(tempInvoice);

                try
                {
                    db.SubmitChanges();
                    return true;
                }catch(Exception ex)
                {
                    ex.GetBaseException();
                    return false;

                }
            }
            else
            {
                return false;
            }
            
        }


        //This will be used to add new products or ingredients on stock
        public bool addStock(int id, int Amount)
        {
            var data = (from i in db.Stocks
                        where i.Id == id
                        select i).FirstOrDefault();

            if(data!=null)
            {

                data.Stock_left += Amount;
                try
                {
                    db.SubmitChanges();
                    return true;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    return false;

                }

            }
            else
            {
                return false;
            }
        }

        //This will be used to refil the stock 
        public bool addStockProduct(Stock s)
        {
            var data = (from i in db.Stocks
                        where i.status == 1 && i.Pro_Name.ToUpper().Equals(s.Pro_Name.ToUpper())
                        select i).FirstOrDefault();

            if (data == null)
            {
                Stock ss = new Stock()
                {
                    Pro_Name = s.Pro_Name,
                    status = 1,
                    Stock_left = s.Stock_left     
                };
                db.Stocks.InsertOnSubmit(ss);

                try
                {
                    db.SubmitChanges();
                    return true;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    return false;

                }

            }
            else
            {
                return false;
            }
        }


        //Responsible for retriving all stocks which will be used in diplaying list to add or delete
        public List<Stock> getAllStocks()
        {
            var data = (from i in db.Stocks
                        where i.status !=0 
                        select i);

            if(data!=null)
            {
                List<Stock> st = new List<Stock>();
                foreach(Stock k in db.Stocks)
                {
                    st.Add(k);
                }
                return st;
            }else
            {
                return null;
            }
        }


        //Returns stock, will be used locally
        public Stock getStock(int id)
        {
            var data = (from i in db.Stocks
                        where i.status == 1 && i.Id == id
                        select i).FirstOrDefault();

            return data;
        }

        //Responsible for returning all invoicess of thee specified date
        public List<Invoice> getDailyAllInvoicesByDate(DateTime d)
        {
            var data = (from i in db.Invoices
                        orderby i.Product_Id descending
                        where i.IssueDate.Date == d.Date.Date
                        select i);

            if(data !=null)
            {
                List<Invoice> Iv = new List<Invoice>();
                foreach(Invoice x in data)
                {
                    Iv.Add(x);
                }

                return Iv;
            }else
            {
                return null;
            }
        }


        //Returns all the dates where the was sales distinctly, this method will beused to display dates to sort invoices
        public List<iDate> getAllDates()
        {
            var data = (from i in db.iDates
                        orderby i.Date_ descending
                        select i);
            
            if (data != null)
            {
                List<iDate> Iv = new List<iDate>();
                foreach (iDate x in data)
                {
                    Iv.Add(x);
                }

                return Iv;
            }
            else
            {
                return null;
            }
        }


        //Responsible for deleting item on stock list
        public bool deleteStock(int id)
        {
            var data = (from i in db.Stocks
                        where i.status == 1 && i.Id == id
                        select i).FirstOrDefault();

            if(data!=null)
            {
                data.status = 0;

                try
                {
                    db.SubmitChanges();
                    return true;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    return false;

                }
            }
            else
            {
                return false;
            }
        }

        //Responsible for detucting stock when is customer buys orwhen they prepare meal
        public bool useStock(int id, int Amount)
        {
            var data = (from i in db.Stocks
                        where i.Id == id
                        select i).FirstOrDefault();
            if(data!=null)
            {
                data.Stock_left -= Amount;
                try
                {
                    db.SubmitChanges();
                    return true;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    return false;

                }

            }
            else
            {
                return false;
            }
        }
    }
}
